# game/session_app.py
import os, json, time, socket, secrets
from pathlib import Path
from urllib.parse import parse_qs

from flask import Flask, request
from flask_socketio import SocketIO, emit, join_room

from engine.core import Engine
from engine.engine_runner import EngineRunner
from engine.logging.replay_recorder import ReplayRecorder
from eventlet.semaphore import Semaphore as EventletSemaphore  # same API as RLock for our use

try:
    import orjson
except Exception:
    orjson = None

try:
    import redis
except Exception:
    redis = None

try:
    from google.cloud import storage
except Exception:
    print('[WARN] google.cloud.storage not available')
    storage = None

# -----------------------------
# JSON compat (Socket.IO serializer)
# -----------------------------
def _orjson_default(x):
    try:
        import numpy as np
        if isinstance(x, (np.integer, np.floating)): return x.item()
        if isinstance(x, np.ndarray): return x.tolist()
    except Exception:
        pass
    try:
        from pathlib import Path as _P
        if isinstance(x, _P): return str(x)
    except Exception:
        pass
    if isinstance(x, set): return list(x)
    if hasattr(x, "model_dump"): return x.model_dump()
    if hasattr(x, "dict"): return x.dict()
    return str(x)

class OrjsonCompat:
    @staticmethod
    def dumps(obj, **kwargs) -> str:
        default = kwargs.get("default", _orjson_default)
        if orjson is not None:
            try:
                return orjson.dumps(obj, default=default).decode("utf-8")
            except Exception:
                pass
        return json.dumps(obj, **kwargs)

    @staticmethod
    def loads(s, **kwargs):
        if orjson is not None:
            try:
                return orjson.loads(s)
            except Exception:
                pass
        return json.loads(s, **kwargs)

# -----------------------------
# Env / Socket.IO / Redis config
# -----------------------------
use_compress = os.getenv("SOCKIO_COMPRESS", "0") == "1"
force_base   = os.getenv("SOCKIO_FORCE_BASE", "0") == "1"
mq_url       = None if force_base else os.getenv("REDIS_URL")  # None => BaseManager (single)

SHARD_ID = os.getenv("SHARD_ID", "1")
SHARD_STATE_GS_URL = (os.getenv("SHARD_STATE_GS_URL", "") or "").strip()
NO_KICK = os.getenv("BENCH_NO_KICK", "0") == "1"

# -----------------------------
# GCS CAS helpers
# -----------------------------
_gcs_client = None

def _parse_gs_url(url: str):
    rest = url[len("gs://"):]
    if "/" in rest:
        b, p = rest.split("/", 1)
        return b, p.strip("/")
    return rest, ""

def _resolve_gcs_target():
    """
    Returns (bucket_name, blob_path) or (None, None) if not configured.
    Writes to: <prefix>/<SHARD_ID>/state/state.json (prefix may be empty)
    """
    if not SHARD_STATE_GS_URL.startswith("gs://"):
        return None, None
    bucket, prefix = _parse_gs_url(SHARD_STATE_GS_URL)
    parts = [p for p in [prefix, SHARD_ID, "state", "state.json"] if p]
    return bucket, "/".join(parts)

def _read_gcs_state():
    bucket_name, blob_path = _resolve_gcs_target()
    if not bucket_name or not blob_path or storage is None:
        return None, None
    global _gcs_client
    if _gcs_client is None:
        _gcs_client = storage.Client()
    b = _gcs_client.bucket(bucket_name)
    blob = b.blob(blob_path)
    if not blob.exists():
        return None, None
    return json.loads(blob.download_as_text()), blob.generation

def _cas_update(edit_fn):
    """
    Generic read-modify-write with if_generation_match.
    Returns True on success, False otherwise.
    """
    st, gen = _read_gcs_state()
    if st is None:
        return False
    new_st = edit_fn(dict(st))  # work on a copy
    if new_st is None:
        return False
    body = json.dumps(new_st, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    bucket_name, blob_path = _resolve_gcs_target()
    b = _gcs_client.bucket(bucket_name)
    blob = b.blob(blob_path)
    try:
        blob.upload_from_string(body, content_type="application/json", if_generation_match=gen)
        blob.cache_control = "no-store"
        blob.patch()
        return True
    except Exception:
        return False

def _write_state_out(payload: dict):
    """CAS-safe writer used by Session to publish nr_players/started/end_time/etc."""
    def edit(st):
        st.update(payload or {})
        return st
    _cas_update(edit)

def _claim_accept(pid: str) -> bool:
    """
    Consume one claimed seat for this pid (if present and not expired).
    Returns True only if pid was claimed and consumed atomically.
    """
    if not pid:
        return False

    accepted = False
    still_valid = True

    def edit(st):
        nonlocal accepted, still_valid
        now = time.time()
        deadline = float(st.get("claim_deadline", 0))
        if deadline and now > deadline:
            # expire stale claim
            st["claimed_players"] = []
            st["claim_deadline"] = 0
            still_valid = False
            return st
        claimed = list(st.get("claimed_players", []))
        if pid in claimed:
            claimed.remove(pid)
            st["claimed_players"] = claimed
            accepted = True
        return st

    ok = _cas_update(edit)
    return bool(ok and accepted and still_valid)

# -----------------------------
# Session model
# -----------------------------
class Session:
    def __init__(self,
                 game_factory,
                 ui_modules,
                 agent_map,
                 tick_rate,
                 ai_tick_rate,
                 is_max_speed,
                 socketio,
                 max_game_time=None,
                 redirect_link=None,
                 url_params=None,
                 n_players: int = 2):
        self.id = secrets.token_hex(8)
        self.recorder = ReplayRecorder(self.id)

        self.game_start_time = None
        self._dirty = False
        self._last_emitted_tick = -1
        self._emitter_started = False
        self._started_global = False
        self._ended = False

        self.socketio = socketio
        self.sid_to_agent = {}
        self.agent_to_sid = {}
        self._maps_lock = EventletSemaphore(1)

        self.engine = Engine(game_factory(url_params=url_params),
                             tick_rate=tick_rate,
                             is_max_speed=is_max_speed,
                             replay_recorder=self.recorder)
        self.engine.add_on_tick_callback(self.broadcast_state)
        self.engine.add_on_game_end_callback(self.handle_game_end)
        self.recorder.set_config(self.engine.game.serialize_initial_state())

        self.ui_modules = ui_modules
        self._agents = []
        self.websockets = {}
        self.max_game_time = max_game_time
        self.redirect_link = redirect_link
        self.n_players = n_players

        self._runner = EngineRunner(
            game=self.engine.game,
            engine=self.engine,
            agent_map=agent_map,
            tick_rate=tick_rate,
            ai_tick_rate=ai_tick_rate,
            is_max_speed=is_max_speed,
            session=self
        )

    def register_websocket(self, agent_id, sid):
        with self._maps_lock:
            self.agent_to_sid[agent_id] = sid
            self.sid_to_agent[sid] = agent_id

    def get_agent_id_by_sid(self, sid):
        with self._maps_lock:
            return self.sid_to_agent.get(sid)

    def has_active_websockets(self):
        with self._maps_lock:
            return any(self.sid_to_agent)

    # ---- HARD CAPACITY GUARD (idempotent) ----
    def add_agent(self, agent_id, url_params=None):
        with self._maps_lock:
            if len(self._agents) >= self.n_players:
                return False  # refuse over-capacity
            if agent_id in self._agents:
                return True
            if hasattr(self.engine.game, "add_agent"):
                self.engine.game.add_agent(agent_id, url_params=url_params)
            self._agents.append(agent_id)
            self.recorder.register_agent(agent_id, self.engine.game.agent_initial_state(agent_id))
            # publish state for visibility (optional)
            _write_state_out({"nr_players": len(self.sid_to_agent), "started": self._started_global})
            return True

    def register_agent(self, agent_id, initial_state):
        self.recorder.register_agent(agent_id, initial_state)

    def is_full(self, max_agents):
        return len(self._agents) >= max_agents

    def start(self):
        self.game_start_time = time.time()
        self._runner.start()
        if not self._emitter_started:
            self._emitter_started = True
            self.socketio.start_background_task(self._emit_loop)

    def broadcast_state(self):
        self._dirty = True

    def _emit_loop(self):
        while not self.engine.game.done:
            if self._dirty and self.engine.tick_count != self._last_emitted_tick:
                self._dirty = False
                self._last_emitted_tick = self.engine.tick_count
                self._emit_once()
            self.socketio.sleep(0.001)
        self.handle_game_end()

    def _emit_once(self):
        game = self.engine.game
        engine = self.engine
        with self._maps_lock:
            recipients = list(self.agent_to_sid.items())
        for agent_id, sid in recipients:
            payload = {"type": "state", "you": agent_id, "tick": engine.tick_count}
            for module in self.ui_modules:
                payload.update(module.serialize_for_agent(game, engine, agent_id))
            try:
                self.socketio.emit("state", payload, to=sid)
            except Exception as e:
                print(f"[WS] Error sending to {agent_id}: {e}")

    def handle_game_end(self):
        if self._ended:
            return
        self._ended = True
        self._started_global = False

        print(f"[Session {self.id}] Game ended. Disconnecting clients and saving replay.")
        self.recorder.save()
        _write_state_out({"nr_players": 0, "started": False, "end_time": time.time()})
        print('[Session] Replay saved.')

        for sid in list(self.sid_to_agent.keys()):
            try:
                if not NO_KICK:
                    if self.redirect_link is not None:
                        redirect_link = self.engine.game.redirect_link() if hasattr(self.engine.game, "redirect_link") else self.redirect_link
                        self.socketio.emit("redirect", {"url": redirect_link}, to=sid)
                        self.socketio.sleep(0.5)
                    self.socketio.server.disconnect(sid)
            except Exception as e:
                print(f"[WS] Error disconnecting {sid}: {e}")