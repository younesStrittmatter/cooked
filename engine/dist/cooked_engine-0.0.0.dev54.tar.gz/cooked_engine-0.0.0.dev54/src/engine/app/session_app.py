# game/session_app.py
import os, json, time, socket, secrets
from pathlib import Path
from urllib.parse import parse_qs

from flask import Flask, request
from flask_socketio import SocketIO, emit, join_room

from engine.core import Engine
from engine.session.session import Session
from engine.engine_runner import EngineRunner
from engine.logging.replay_recorder import ReplayRecorder
from eventlet.semaphore import Semaphore as EventletSemaphore  # same API as RLock for our use

try:
    import orjson
except Exception:
    orjson = None

try:
    import redis
except Exception:
    redis = None

try:
    from google.cloud import storage
except Exception:
    print('[WARN] google.cloud.storage not available')
    storage = None

# -----------------------------
# JSON compat (Socket.IO serializer)
# -----------------------------
def _orjson_default(x):
    try:
        import numpy as np
        if isinstance(x, (np.integer, np.floating)): return x.item()
        if isinstance(x, np.ndarray): return x.tolist()
    except Exception:
        pass
    try:
        from pathlib import Path as _P
        if isinstance(x, _P): return str(x)
    except Exception:
        pass
    if isinstance(x, set): return list(x)
    if hasattr(x, "model_dump"): return x.model_dump()
    if hasattr(x, "dict"): return x.dict()
    return str(x)

class OrjsonCompat:
    @staticmethod
    def dumps(obj, **kwargs) -> str:
        default = kwargs.get("default", _orjson_default)
        if orjson is not None:
            try:
                return orjson.dumps(obj, default=default).decode("utf-8")
            except Exception:
                pass
        return json.dumps(obj, **kwargs)

    @staticmethod
    def loads(s, **kwargs):
        if orjson is not None:
            try:
                return orjson.loads(s)
            except Exception:
                pass
        return json.loads(s, **kwargs)

# -----------------------------
# Env / Socket.IO / Redis config
# -----------------------------
use_compress = os.getenv("SOCKIO_COMPRESS", "0") == "1"
force_base   = os.getenv("SOCKIO_FORCE_BASE", "0") == "1"
mq_url       = None if force_base else os.getenv("REDIS_URL")  # None => BaseManager (single)

SHARD_ID = os.getenv("SHARD_ID", "1")
SHARD_STATE_GS_URL = (os.getenv("SHARD_STATE_GS_URL", "") or "").strip()
NO_KICK = os.getenv("BENCH_NO_KICK", "0") == "1"

# -----------------------------
# GCS CAS helpers
# -----------------------------
_gcs_client = None

def _parse_gs_url(url: str):
    rest = url[len("gs://"):]
    if "/" in rest:
        b, p = rest.split("/", 1)
        return b, p.strip("/")
    return rest, ""

def _resolve_gcs_target():
    """
    Returns (bucket_name, blob_path) or (None, None) if not configured.
    Writes to: <prefix>/<SHARD_ID>/state/state.json (prefix may be empty)
    """
    if not SHARD_STATE_GS_URL.startswith("gs://"):
        return None, None
    bucket, prefix = _parse_gs_url(SHARD_STATE_GS_URL)
    parts = [p for p in [prefix, SHARD_ID, "state", "state.json"] if p]
    return bucket, "/".join(parts)

def _read_gcs_state():
    bucket_name, blob_path = _resolve_gcs_target()
    if not bucket_name or not blob_path or storage is None:
        return None, None
    global _gcs_client
    if _gcs_client is None:
        _gcs_client = storage.Client()
    b = _gcs_client.bucket(bucket_name)
    blob = b.blob(blob_path)
    if not blob.exists():
        return None, None
    return json.loads(blob.download_as_text()), blob.generation

def _cas_update(edit_fn):
    """
    Generic read-modify-write with if_generation_match.
    Returns True on success, False otherwise.
    """
    st, gen = _read_gcs_state()
    if st is None:
        return False
    new_st = edit_fn(dict(st))  # work on a copy
    if new_st is None:
        return False
    body = json.dumps(new_st, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    bucket_name, blob_path = _resolve_gcs_target()
    b = _gcs_client.bucket(bucket_name)
    blob = b.blob(blob_path)
    try:
        blob.upload_from_string(body, content_type="application/json", if_generation_match=gen)
        blob.cache_control = "no-store"
        blob.patch()
        return True
    except Exception:
        return False

def _write_state_out(payload: dict):
    """CAS-safe writer used by Session to publish nr_players/started/end_time/etc."""
    def edit(st):
        st.update(payload or {})
        return st
    _cas_update(edit)

def _claim_accept(pid: str) -> bool:
    """
    Consume one claimed seat for this pid (if present and not expired).
    Returns True only if pid was claimed and consumed atomically.
    """
    if not pid:
        return False

    accepted = False
    still_valid = True

    def edit(st):
        nonlocal accepted, still_valid
        now = time.time()
        deadline = float(st.get("claim_deadline", 0))
        if deadline and now > deadline:
            # expire stale claim
            st["claimed_players"] = []
            st["claim_deadline"] = 0
            still_valid = False
            return st
        claimed = list(st.get("claimed_players", []))
        if pid in claimed:
            claimed.remove(pid)
            st["claimed_players"] = claimed
            accepted = True
        return st

    ok = _cas_update(edit)
    return bool(ok and accepted and still_valid)

# -----------------------------

# -----------------------------
# SessionApp (w/ claim validation)
# -----------------------------
class SessionApp:
    def __init__(self,
                 game_factory,
                 ui_modules=None,
                 agent_map=None,
                 path_root=None,
                 tick_rate=24,
                 ai_tick_rate=5,
                 n_players=2,
                 is_max_speed=False,
                 max_game_time=None,
                 redirect_link=None):
        self.max_game_time = max_game_time

        self.app = Flask(__name__)
        self.app.config["SECRET_KEY"] = "replace-this-if-needed"

        self._redis = self._make_redis()
        self._sid_to_roomkey = {}  # sid -> room key (for forwarding)

        self.socketio = SocketIO(self.app,
                                 cors_allowed_origins="*",
                                 async_mode="eventlet",
                                 ping_interval=30,
                                 ping_timeout=40,
                                 websocket_compression=use_compress,
                                 message_queue=(None if self._redis is None else os.getenv("REDIS_URL")),
                                 json=OrjsonCompat)

        print("SocketIO manager:", type(self.socketio.server.manager).__name__,
              "| compression:", use_compress, "| redis:", bool(self._redis))

        self.path_root = Path(path_root) if path_root else Path(__file__).resolve().parents[1] / "game"
        self.ui_modules = (ui_modules or [])

        self.session_manager = self._make_session_manager(game_factory, n_players, ui_modules, agent_map,
                                                          tick_rate, ai_tick_rate, is_max_speed,
                                                          max_game_time, redirect_link)

        self._register_websocket_routes()

    @staticmethod
    def _make_redis():
        url = os.getenv("REDIS_URL")
        if not url or not redis:
            return None
        try:
            return redis.Redis.from_url(url)
        except Exception:
            return None

    # ---- session manager facade (minimal) ----
    class _SessionManager:
        def __init__(self, n_players):
            self.n_players = n_players
            self.sessions = {}

        def generate_agent_id(self):
            return secrets.token_hex(4)

        def find_or_create_session(self, params):
            # single-session-per-process demo; you may key by lobby room if you prefer
            sid = "default"
            sess = self.sessions.get(sid)
            if not sess:
                sess = self.factory(self.game_factory, self.ui_modules, self.agent_map,
                                    self.tick_rate, self.ai_tick_rate, self.is_max_speed,
                                    self.socketio, self.max_game_time, self.redirect_link,
                                    params, self.n_players)
                self.sessions[sid] = sess
            return sess

        def get_session(self, session_id):
            # trivial: we only keep one; adapt to your real ID map
            return next(iter(self.sessions.values()), None)

        # wiring set by outer class:
        factory = None
        game_factory = None
        ui_modules = None
        agent_map = None
        tick_rate = None
        ai_tick_rate = None
        is_max_speed = None
        socketio = None
        max_game_time = None
        redirect_link = None

    def _make_session_manager(self, game_factory, n_players, ui_modules, agent_map,
                              tick_rate, ai_tick_rate, is_max_speed, max_game_time, redirect_link):
        m = SessionApp._SessionManager(n_players=n_players)
        m.factory = lambda gf, um, am, tr, ar, ims, sio, mgt, rlink, params, np: Session(
            game_factory=gf,
            ui_modules=um,
            agent_map=am or {},
            tick_rate=tr,
            ai_tick_rate=ar,
            is_max_speed=ims,
            socketio=sio,
            max_game_time=mgt,
            redirect_link=rlink,
            url_params=params,
            n_players=np
        )
        m.game_factory = game_factory
        m.ui_modules = ui_modules or []
        m.agent_map = agent_map or {}
        m.tick_rate = tick_rate
        m.ai_tick_rate = ai_tick_rate
        m.is_max_speed = is_max_speed
        m.socketio = self.socketio
        m.max_game_time = max_game_time
        m.redirect_link = redirect_link
        return m

    # ---------- owner election (optional for multi-worker) ----------
    def _owner_elect(self, room_key: str) -> bool:
        if not self._redis or not room_key:
            return True
        key = f"sess:{room_key}:owner"
        try:
            owner_id = f"{socket.gethostname()}:{os.getpid()}"
            return bool(self._redis.set(key, owner_id, nx=True, ex=24*3600))
        except Exception:
            return True

    def _set_canonical_session_id(self, room_key: str, session_id: str):
        if not self._redis:
            return
        try:
            self._redis.set(f"sess:{room_key}:sid", session_id, ex=24*3600)
        except Exception:
            pass

    def _get_canonical_session_id(self, room_key: str):
        if not self._redis:
            return None
        try:
            v = self._redis.get(f"sess:{room_key}:sid")
            return v.decode() if v else None
        except Exception:
            return None

    def _pub(self, room_key: str, event: str, payload: dict):
        if not self._redis:
            return
        chan = f"sess:{room_key}:ctrl"
        try:
            self._redis.publish(chan, json.dumps({"event": event, "data": payload}))
        except Exception as e:
            print("[REDIS PUBLISH] error:", e)

    # ---------- WebSocket routes ----------
    def _register_websocket_routes(self):
        @self.socketio.on("connect")
        def on_connect(auth=None):
            sid = request.sid
            params = parse_qs(request.query_string.decode())
            if auth and isinstance(auth, dict):
                for k, v in auth.items():
                    params.setdefault(k, []).append(v)

            room_key = params.get("room", [None])[0] if self._redis else None
            waiting_id = params.get("pid", [None])[0]
            agent_id = self.session_manager.generate_agent_id()

            # Require claim consumption before join (protects against over-redirect)
            if self.session_manager.n_players > 0:
                if not _claim_accept(waiting_id):
                    emit("wait_or_full", {"reason": "not_claimed"})
                    from flask_socketio import disconnect
                    disconnect()
                    return

            if self._redis and room_key:
                room = f"sesskey:{room_key}"
                join_room(room)

                if self._owner_elect(room_key):
                    # owner creates canonical session
                    session = self.session_manager.find_or_create_session(params)
                    setattr(session, "room", room)

                    ok = session.add_agent(agent_id, url_params=params)
                    if not ok:
                        emit("room_full", {"reason": "capacity_reached"})
                        from flask_socketio import disconnect
                        disconnect()
                        return

                    session.register_websocket(agent_id, sid)
                    _write_state_out({"nr_players": len(session.sid_to_agent), "started": session._started_global})

                    self._set_canonical_session_id(room_key, session.id)

                    if session.is_full(self.session_manager.n_players):
                        print(f"[SessionApp] (owner) Session {session.id} full, starting game")
                        session._started_global = True
                        session.start()

                    emit("joined", {"agent_id": agent_id, "session_id": session.id})

                else:
                    # non-owner forwards to owner
                    self._sid_to_roomkey[sid] = room_key
                    self._pub(room_key, "join", {"agent_id": agent_id, "sid": sid, "url_params": params})
                    canon_id = None
                    deadline = time.time() + 2.0
                    while time.time() < deadline and not canon_id:
                        canon_id = self._get_canonical_session_id(room_key)
                        if not canon_id:
                            self.socketio.sleep(0.05)
                    emit("joined", {"agent_id": agent_id, "session_id": canon_id or room_key})

            else:
                # single-worker path
                session = self.session_manager.find_or_create_session(params)
                room = f"session:{session.id}"
                join_room(room)
                setattr(session, "room", room)

                ok = session.add_agent(agent_id, url_params=params) if self.session_manager.n_players > 0 else True
                if not ok:
                    emit("room_full", {"reason": "capacity_reached"})
                    from flask_socketio import disconnect
                    disconnect()
                    return

                session.register_websocket(agent_id, sid)
                _write_state_out({"nr_players": len(session.sid_to_agent), "started": session._started_global})

                if session.is_full(self.session_manager.n_players):
                    print(f"[CTRL] Session {session.id} full; starting")
                    session._started_global = True
                    session.start()

                emit("joined", {"agent_id": agent_id, "session_id": session.id})

        @self.socketio.on("intent")
        def handle_intent(data):
            session = self.session_manager.get_session(data.get("session_id", ""))
            if session:
                action = data.get("action")
                if isinstance(action, str):
                    action = {"type": action}
                elif action is None:
                    action = {}
                session.engine.submit_intent(data["agent_id"], action)
                return

            sid = request.sid
            room_key = self._sid_to_roomkey.get(sid)
            if self._redis and room_key:
                action = data.get("action")
                if isinstance(action, str):
                    action = {"type": action}
                elif action is None:
                    action = {}
                self._pub(room_key, "intent", {"agent_id": data["agent_id"], "action": action})

        @self.socketio.on("disconnect")
        def on_disconnect():
            sid = request.sid
            for session in self.session_manager.sessions.values():
                with session._maps_lock:
                    agent_id = session.sid_to_agent.get(sid)
                    if agent_id:
                        # If not full yet, remove agent entirely; otherwise just drop socket
                        if not session.is_full(self.session_manager.n_players):
                            if hasattr(session.engine.game, "remove_agent"):
                                session.engine.game.remove_agent(agent_id)
                            if agent_id in session._agents:
                                session._agents.remove(agent_id)
                            session.recorder.unregister_agent(agent_id)
                        session.websockets.pop(agent_id, None)
                        session.agent_to_sid.pop(agent_id, None)
                        session.sid_to_agent.pop(sid, None)
                        if session._started_global and len(session.sid_to_agent) < 1:
                            session.handle_game_end()
                        else:
                            _write_state_out({"nr_players": len(session.sid_to_agent), "started": session._started_global})
                        break
            else:
                room_key = self._sid_to_roomkey.pop(sid, None)
                if self._redis and room_key:
                    self._pub(room_key, "disconnect", {"sid": sid})

    # Expose WSGI app/socketio if needed by your runner
    def wsgi_app(self):
        return self.app

    def run(self, host="0.0.0.0", port:int = int(os.getenv("PORT","8080")), debug=False):
        self.socketio.run(self.app, host=host, port=port, debug=debug)