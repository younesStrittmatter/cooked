// renderer_ui.js

import { sendIntent } from "/engine/static/engine_ui.js";

/**
 * Build asset base & version lazily so we don't race against /asset-config.js
 */
function getBase() {
  const b = (window.ASSET_BASE_URL || "/sprites/").replace(/\/+$/, "");
  return b + "/";
}
function getVerQ() {
  return window.ASSET_VERSION ? `?v=${encodeURIComponent(window.ASSET_VERSION)}` : "";
}

let canvas = document.getElementById("scene");
let text_overlay = document.getElementById("text_overlay");

if (!canvas) {
  canvas = document.createElement("canvas");
  canvas.id = "scene";
  canvas.width = 128;
  canvas.height = 128;
  document.body.appendChild(canvas);
}
if (!text_overlay) {
  // Must be a <canvas>, not a custom element
  text_overlay = document.createElement("canvas");
  text_overlay.id = "text_overlay";
  text_overlay.width = 1024;
  text_overlay.height = 1024;
  document.body.appendChild(text_overlay);
}

const ctx = canvas.getContext("2d");
ctx.imageSmoothingEnabled = false;
const ctx_text = text_overlay.getContext("2d");

const spriteCache = {};
let currentState = null;

/**
 * Load a sprite with:
 *  - primary: GCS (or base from env)
 *  - fallback: local /sprites/ (only if primary isn't already local)
 */
function loadSprite(src) {
  return new Promise((resolve, reject) => {
    if (spriteCache[src]) return resolve(spriteCache[src]);

    const primary = getBase() + src + getVerQ();
    const fallback = "/sprites/" + src + getVerQ();

    const img = new Image();
    img.crossOrigin = "anonymous"; // safe for canvas when using GCS/CDN
    img.decoding = "async";
    img.src = primary;
    img.onload = () => {
      spriteCache[src] = img;
      resolve(img);
    };
    img.onerror = () => {
      // If primary isn't local, try the local fallback once
      if (!getBase().startsWith("/sprites/")) {
        const img2 = new Image();
        img2.crossOrigin = "anonymous";
        img2.decoding = "async";
        img2.src = fallback;
        img2.onload = () => {
          spriteCache[src] = img2;
          resolve(img2);
        };
        img2.onerror = () => reject(new Error(`Failed to load ${primary} and ${fallback}`));
      } else {
        reject(new Error(`Failed to load ${primary}`));
      }
    };
  });
}

/**
 * Click → send intent to server for the top-most clickable object under cursor
 */
canvas.addEventListener("click", async (event) => {
  const rect = canvas.getBoundingClientRect();
  const scaleX = canvas.width / rect.width;
  const scaleY = canvas.height / rect.height;
  const clickX = (event.clientX - rect.left) * scaleX;
  const clickY = (event.clientY - rect.top) * scaleY;

  const objects = currentState?.gameObjects || [];
  // If zIndex is used, clickable top-most should be last after sort in renderScene
  for (let i = objects.length - 1; i >= 0; i--) {
    const obj = objects[i];
    if (obj.isClickable) {
      const withinX = clickX >= obj.left && clickX <= obj.left + obj.width;
      const withinY = clickY >= obj.top && clickY <= obj.top + obj.height;
      if (withinX && withinY) {
        await sendIntent({ type: "click", target: obj.id });
        return;
      }
    }
  }
});

/**
 * Render scene with simple interpolation between prevState and currState
 */
export async function renderScene(prevState = { gameObjects: [] }, currState = { gameObjects: [] }, t = 1) {
  const objects = (currState && currState.gameObjects) ? currState.gameObjects.slice() : [];
  currentState = currState;

  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx_text.clearRect(0, 0, text_overlay.width, text_overlay.height);

  // draw back-to-front
  objects.sort((a, b) => (a.zIndex || 0) - (b.zIndex || 0));

  for (const obj of objects) {
    if (obj.class === "Basic2D") {
      let s_x = canvas.width;
      let s_y = canvas.height;
      if (!obj.normalize) {
        s_x = 1;
        s_y = 1;
      }

      const img = await loadSprite(obj.src);
      const id = obj.id;

      const currX = (obj.left ?? 0) * s_x;
      const currY = (obj.top ?? 0) * s_y;

      const prevObj = (prevState?.gameObjects || []).find(o => o.id === id);
      const prevX = prevObj ? (prevObj.left ?? 0) * s_x : currX;
      const prevY = prevObj ? (prevObj.top ?? 0) * s_y : currY;

      const x = prevX + (currX - prevX) * t;
      const y = prevY + (currY - prevY) * t;

      const w = (obj.width ?? img.width) * s_x;
      const h = (obj.height ?? img.height) * s_y;

      ctx.drawImage(
        img,
        obj.srcX || 0, obj.srcY || 0,
        obj.srcW || img.width, obj.srcH || img.height,
        Math.round(x), Math.round(y),
        Math.round(w), Math.round(h)
      );
    }

    if (obj.class === "Text") {
      let s_x = text_overlay.width;
      let s_y = text_overlay.height;
      if (!obj.normalize) {
        s_x = 1;
        s_y = 1;
      }

      const computeXY = (o, sx, sy) => {
        const left = o.left;
        const top = o.top;
        const right = o.right;
        const bottom = o.bottom;

        const x = (left === null || left === undefined)
          ? text_overlay.width - (right ?? 0) * sx
          : (left ?? 0) * sx;

        const y = (top === null || top === undefined)
          ? text_overlay.height - (bottom ?? 0) * sy
          : (top ?? 0) * sy;

        return { x, y };
      };

      const { x: currX, y: currY } = computeXY(obj, s_x, s_y);
      const prevObj = (prevState?.gameObjects || []).find(o => o.id === obj.id) || {};
      const { x: prevX, y: prevY } = computeXY(prevObj, s_x, s_y);

      const x = prevX + (currX - prevX) * t;
      const y = prevY + (currY - prevY) * t;

      const lines = String(obj.content || "").split("\n");
      const fontSize = obj.fontSize || 48;
      ctx_text.font = `${fontSize}pt ${obj.fontFamily || "Arial"}`;
      ctx_text.fillStyle = obj.color || "black";
      ctx_text.textAlign = obj.align || "left";
      ctx_text.textBaseline = obj.baseline || "top";

      if (obj.top === null || obj.top === undefined) {
        // bottom-anchored
        lines.forEach((line, i) => {
          ctx_text.fillText(
            line,
            Math.round(x),
            Math.round(y - lines.length * fontSize * 1.5 + i * fontSize * 1.5) + fontSize * 1.5
          );
        });
      } else {
        // top-anchored
        lines.forEach((line, i) => {
          ctx_text.fillText(line, Math.round(x), Math.round(y + i * fontSize * 1.5));
        });
      }
    }
  }
}

/**
 * Mouse tracking & intents
 */
const mouse = {
  x: 0,
  y: 0,
  leftDown: false,
  rightDown: false
};

function isWithinCanvas(x, y) {
  return x >= 0 && x <= canvas.width && y >= 0 && y <= canvas.height;
}

function getCanvasPosition(clientX, clientY) {
  const rect = canvas.getBoundingClientRect();
  const scaleX = 1 / rect.width;
  const scaleY = 1 / rect.height;
  return {
    x: (clientX - rect.left) * scaleX,
    y: (clientY - rect.top) * scaleY
  };
}

// Mouse events
canvas.addEventListener("mousemove", (e) => {
  const pos = getCanvasPosition(e.clientX, e.clientY);
  if (isWithinCanvas(pos.x, pos.y)) {
    mouse.x = pos.x;
    mouse.y = pos.y;
  }
});

canvas.addEventListener("mousedown", (e) => {
  if (e.button === 0) mouse.leftDown = true;
  if (e.button === 2) mouse.rightDown = true;
});

canvas.addEventListener("mouseup", (e) => {
  if (e.button === 0) mouse.leftDown = false;
  if (e.button === 2) mouse.rightDown = false;
});

canvas.addEventListener("contextmenu", (e) => e.preventDefault());

// Touch events
canvas.addEventListener("touchstart", (e) => {
  const touch = e.touches[0];
  const pos = getCanvasPosition(touch.clientX, touch.clientY);
  if (isWithinCanvas(pos.x, pos.y)) {
    mouse.x = pos.x;
    mouse.y = pos.y;
  }
  mouse.leftDown = true;
});

canvas.addEventListener("touchmove", (e) => {
  const touch = e.touches[0];
  const pos = getCanvasPosition(touch.clientX, touch.clientY);
  if (isWithinCanvas(pos.x, pos.y)) {
    mouse.x = pos.x;
    mouse.y = pos.y;
  }
});

canvas.addEventListener("touchend", () => {
  mouse.leftDown = false;
});

// Disable context menu on right-click
canvas.addEventListener("contextmenu", (e) => e.preventDefault());

export async function updateMouse() {
  await sendIntent({
    type: "mouse",
    x: mouse.x,
    y: mouse.y,
    leftDown: mouse.leftDown,
    rightDown: mouse.rightDown
  });
}
