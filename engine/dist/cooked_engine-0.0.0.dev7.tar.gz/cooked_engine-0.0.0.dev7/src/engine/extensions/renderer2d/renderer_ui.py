from engine.interface.ui_module import UIModule
from flask import send_from_directory, Response
from pathlib import Path
import os


def _asset_base_from_env() -> str:
    """
    Priority:
      1) ASSET_BASE_URL (e.g. https://storage.googleapis.com/<bucket>/)
      2) If ASSET_BUCKET is set, use GCS public URL
      3) Fallback to local /sprites/ (dev)
    """
    base = os.getenv("ASSET_BASE_URL", "").strip()
    if base:
        return base.rstrip("/") + "/"

    bucket = os.getenv("ASSET_BUCKET", "").strip()
    if bucket:
        return f"https://storage.googleapis.com/{bucket}/"

    return "/sprites/"  # dev fallback


class Renderer2DModule(UIModule):
    def __init__(self, sprite_folder_name="sprites"):
        self.sprite_folder_name = sprite_folder_name
        self._path_root = None
        self._static_path = Path(__file__).parent / "static"
        self._module_name = Path(__file__).parent.name

    def serialize_for_agent(self, game, engine, agent_id: str) -> dict:
        return {
            "objects": getattr(game, "objects", [])
        }

    def get_static_path(self):
        return self._static_path

    def get_client_scripts(self) -> list[str]:
        return ["/asset-config.js", f"/extensions/{self._module_name}/static/renderer_ui.js"]

    def register_routes(self, app):
        @app.route("/asset-config.js")
        def asset_config():
            version = os.getenv("ASSET_VERSION", "")
            js = (
                f'window.ASSET_BASE_URL="{self._asset_base}";'
                f'window.ASSET_VERSION="{version}";'
            )
            return Response(js, 200, {"Content-Type":"application/javascript","Cache-Control":"no-store"})

        @app.route("/sprites/<path:filename>")
        def serve_sprite(filename):
            if not self._path_root:
                raise RuntimeError("Renderer2DModule requires `path_root` to be set.")
            sprite_path = self._path_root / "static" / self.sprite_folder_name
            return send_from_directory(sprite_path, filename)

    def set_path_root(self, path_root):
        self._path_root = Path(path_root)
